#pragma once

namespace aps {
namespace conf {

extern bool verbose;

}
}
