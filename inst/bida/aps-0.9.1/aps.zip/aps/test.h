#pragma once

#include "common.h"

namespace aps {

void runTests();

}
