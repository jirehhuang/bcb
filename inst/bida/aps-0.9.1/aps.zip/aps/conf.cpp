#include "conf.h"

namespace aps {
namespace conf {

bool verbose = false;

}
}
