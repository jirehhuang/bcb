#include "common.h"

thread_local std::mt19937 rng(std::random_device{}());
