#pragma once

#include <array>
#include <cassert>
#include <cmath>
#include <random>
#include <iostream>
#include <algorithm>
#include <vector>
#include <chrono>
#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <regex>
#include <set>
#include <map>
#include <deque>
#include <cstdlib>
#include <memory>

extern thread_local std::mt19937 rng;
